<?php include('include/home/header.php'); ?>
<section>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<h2>About Us</h2>
				<p>We are a company that specializes in creating high-quality products and services for our customers. Our team is composed of experienced professionals who are dedicated to providing the best solutions for your needs.</p>
				<p>We believe in the power of innovation and continuous improvement, which is why we are always striving to develop new and better ways to serve our customers. Our commitment to excellence is evident in everything we do, from our customer service to the products and services we offer.</p>
				<p>At our core, we are a company that values integrity, honesty, and respect. We treat our customers, employees, and partners with the utmost respect and professionalism, and we always operate with transparency and honesty in everything we do.</p>
				<p>Thank you for considering our company for your needs. We look forward to serving you and providing the best possible solutions for your business.</p>
			</div>
		</div>
	</div>
</section>
<?php include('include/home/footer.php'); ?>
